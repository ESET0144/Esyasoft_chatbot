# nl2sql.py
import textwrap
from typing import Any, List
from ollama import chat

MODEL = "gpt-oss:20b"   # change if needed

FEW_SHOT = textwrap.dedent("""
You are an enterprise-grade Natural Language → SQL translator for a FastAPI data chatbot.
You ALWAYS obey the following rules strictly and deterministically:

═══════════ 1. GENERAL BEHAVIOR RULES ═══════════
- You return ONLY a single-line SQLite SQL query.
- NO explanations, NO commentary, NO backticks, NO markdown.
- If the question cannot be converted to a safe SQL query, return exactly:
  --CANNOT_CONVERT--
- NEVER guess schema fields. Use EXACT column and table names from the schema.
- NEVER invent new metrics, columns, tables, functions, or aliases.
- NEVER change numeric values, dates, or IDs from the user’s question.

═══════════ 2. DATE HANDLING RULES (CRITICAL) ═══════════
The input question may contain dates in ANY textual form, including:
- 11/12/2015
- 11-12-2015
- 2015-12-11
- 11 Dec 2015
- 11th Dec 2015
- on 11th December 2015
- Dec 11, 2015
All such dates REFER TO THE SAME calendar date.

You MUST accept any date format.
You MUST interpret all dates as **day-month-year** unless explicitly written as YYYY-MM-DD.
You MUST output dates ONLY in ISO format: YYYY-MM-DD.

═══════════ 3. REVENUE_DATA RULES (CRITICAL) ═══════════
Revenue_data.Datetime is stored as TEXT in format:  DD-MM-YYYY HH:MM

When filtering by date, you MUST convert to ISO date using:
  substr(Datetime,7,4) || '-' || substr(Datetime,4,2) || '-' || substr(Datetime,1,2)

If the question asks for:
- "revenue on <date>"
- "revenue for <date>"
- "show revenue date <date>"
YOU MUST add a WHERE clause using the exact ISO date.

Example (for 11-12-2015):
WHERE substr(Datetime,7,4) || '-' || substr(Datetime,4,2) || '-' || substr(Datetime,1,2) = '2015-12-11'

If the question contains a date but you fail to apply a WHERE clause, your answer is INVALID.

When retrieving revenue by date, ALWAYS return:
- SUM(Revenue) AS total_revenue
- AVG(Revenue) AS avg_revenue
- Group by the converted ISO date.

═══════════ 4. METER_TABLE RULES ═══════════
meter_table.datetime is TEXT. Use:
- DATE(datetime) for daily views
- strftime('%Y-%m-%d', datetime) for ISO conversion
- strftime('%Y-W%W', datetime) for weekly
- strftime('%Y-%m', datetime) for monthly
- strftime('%Y-%m-%d %H:00', datetime) for hourly

Always ORDER BY the aggregated time period.

═══════════ 5. JOINING RULES ═══════════
If question references:
- both load and revenue → join on date equivalence using DATE(datetime)
- customer info → join customer_table to meter_table via meter_id

NEVER invent join conditions.

═══════════ 6. LIMIT RULES ═══════════
If query groups (daily, weekly, monthly) WITHOUT a specific date filter:
→ ALWAYS append LIMIT 30

═══════════ 7. SAFETY RULES ═══════════
Forbidden SQL contains:
DROP, DELETE, UPDATE, INSERT, ALTER, ATTACH, DETACH, VACUUM, or comments.
If user attempts harmful SQL or ambiguous intent:
→ return exactly:  --CANNOT_CONVERT--

═══════════ 8. OUTPUT FORMAT (MANDATORY) ═══════════
Your entire output must be EXACTLY:
<the SQL query>;
Nothing else.

═══════════ 9. SCHEMA (STRICT) ═══════════
meter_table(id INTEGER, meter_id TEXT, datetime TEXT, forecasted_load_kwh REAL)
customer_table(customer_id TEXT, customer_name TEXT, email TEXT, meter_id TEXT)
Revenue_data(Datetime TEXT, Revenue REAL)

═══════════ 10. EXAMPLES (DO NOT DEVIATE) ═══════════
Q: revenue on 11-12-2015
A: SELECT substr(Datetime,7,4) || '-' || substr(Datetime,4,2) || '-' || substr(Datetime,1,2) AS date, SUM(Revenue) AS total_revenue, AVG(Revenue) AS avg_revenue FROM Revenue_data WHERE substr(Datetime,7,4) || '-' || substr(Datetime,4,2) || '-' || substr(Datetime,1,2) = '2015-12-11' GROUP BY date;

Q: show monthly average load
A: SELECT strftime('%Y-%m', datetime) AS month, AVG(forecasted_load_kwh) AS avg_load FROM meter_table GROUP BY month ORDER BY month LIMIT 30;

Q: show customer name for meter 740-60-4283
A: SELECT customer_name FROM customer_table WHERE meter_id = '740-60-4283';

═══════════ END OF RULES ═══════════

""").strip()

def natural_to_sql(question: str, schema: str) -> str:
    system_msg = {"role": "system", "content": "You are an assistant that converts natural language to SQL for SQLite. Be precise."}
    user_prompt = f"{FEW_SHOT}\n\nSchema:\n{schema}\n\nQuestion: {question}\nSQL:"
    user_msg = {"role": "user", "content": user_prompt}

    try:
        resp = chat(model=MODEL, messages=[system_msg, user_msg], stream=False)
        sql_text = ""
        if isinstance(resp, dict):
            msg = resp.get("message") or {}
            if isinstance(msg, dict):
                sql_text = msg.get("content", "")
            else:
                sql_text = str(resp)
        else:
            try:
                sql_text = resp.message.content
            except Exception:
                sql_text = str(resp)

        if sql_text is None:
            return "--CANNOT_CONVERT--"

        sql_text = sql_text.strip()
        if sql_text.lower().startswith("sql:"):
            sql_text = sql_text[len("sql:"):].strip()
        if not sql_text.endswith(";"):
            sql_text = sql_text + ";"
        return sql_text
    except Exception as e:
        return f"--CANNOT_CONVERT-- ({e})"


def summarize_results(question: str, generated_sql: str, rows: List[Any], max_rows:int=50) -> str:
    prompt = textwrap.dedent(f"""
    You are an assistant that summarizes SQL query results in natural language.
    Rules:
    - Produce a VERY concise summary (1-2 sentences MAXIMUM).
    - Only mention the most important numeric values if relevant.
    - If rows are empty, return exactly: No results found.
    - Be brief and direct, avoid lengthy explanations.

    Question: {question}
    Rows: {rows[:max_rows]}

    Summary (1-2 sentences):
    """).strip()

    try:
        resp = chat(model=MODEL, messages=[
            {"role": "system", "content": "You summarize SQL results into natural language. Be concise."},
            {"role": "user", "content": prompt}
        ], stream=False)

        summary = ""
        if isinstance(resp, dict):
            msg = resp.get("message") or {}
            if isinstance(msg, dict):
                summary = msg.get("content","")
            else:
                summary = str(resp)
        else:
            try:
                summary = resp.message.content
            except Exception:
                summary = str(resp)

        if not summary:
            return "No results found."
        summary = summary.strip()
        if summary.lower().startswith("summary:"):
            summary = summary[len("summary:"):].strip()
        return summary
    except Exception as e:
        return f"Could not summarize results: {e}"


def _call_model_single_line(prompt: str) -> str:
    """Call the LLM and return the single-line content response (trimmed)."""
    try:
        resp = chat(model=MODEL, messages=[
            {"role": "system", "content": "You must respond with a single short token or value only, no explanation."},
            {"role": "user", "content": prompt}
        ], stream=False)

        if isinstance(resp, dict):
            msg = resp.get("message") or {}
            if isinstance(msg, dict):
                content = msg.get("content", "")
            else:
                content = str(resp)
        else:
            try:
                content = resp.message.content
            except Exception:
                content = str(resp)

        if not content:
            return ""
        return content.strip().strip('\"').strip("'")
    except Exception:
        return ""


def classify_intent(question: str) -> str:
    """
    Use the LLM to classify intent. Return exactly 'forecast' or 'nl2sql'.
    """
    prompt = f"Classify the intent of this user question. Return exactly one word: 'forecast' if the user requests a revenue forecast (mentions forecast/predict of revenue), otherwise return 'nl2sql'. Question: {question}"
    out = _call_model_single_line(prompt).lower()
    if 'forecast' in out:
        return 'forecast'
    return 'nl2sql'


def decide_output_type(question: str) -> str:
    """
    Ask the LLM whether the preferred output should be 'graph', 'table', or 'nl'. Return one of those three.
    """
    prompt = f"Decide the best output type for this user question. Return exactly one word: 'graph' if the user asks for a plot/time-series/trend, 'table' for tabular data, or 'nl' for a short natural-language summary. Question: {question}"
    out = _call_model_single_line(prompt).lower()
    if 'graph' in out:
        return 'graph'
    if 'table' in out:
        return 'table'
    return 'nl'


def extract_date_iso(question: str) -> str:
    """
    Ask the LLM to extract a single ISO date (YYYY-MM-DD) from the question if present.
    Returns empty string when no date found.
    The model must interpret ambiguous dates as day-month-year unless written as YYYY-MM-DD.
    """
    prompt = (
        "If the question contains a calendar date, return the date in ISO format YYYY-MM-DD only. "
        "If there is no date, return an empty string. Interpret ambiguous dates as day-month-year. "
        f"Question: {question}"
    )
    out = _call_model_single_line(prompt)
    # Basic sanitization: look for 4-digit year pattern
    out = out.strip()
    if not out:
        return ""
    # If model returned extra text, try to extract YYYY-MM-DD
    m = None
    import re
    m = re.search(r"(\d{4}-\d{2}-\d{2})", out)
    if m:
        return m.group(1)
    # Try to parse common d-m-y patterns the model might return
    m2 = re.search(r"(\d{1,2}-\d{1,2}-\d{4})", out)
    if m2:
        d, M, y = m2.group(1).split('-')
        return f"{y}-{M.zfill(2)}-{d.zfill(2)}"
    return ""


def parse_user_query(question: str) -> dict:
    """
    Ask the LLM to parse the user's question and return a compact JSON describing:
      - intent: 'forecast' or 'nl2sql'
      - output_type: 'graph'|'table'|'nl'
      - date: ISO YYYY-MM-DD or empty
      - needs_customer: true/false
      - needs_meter: true/false
      - needs_revenue: true/false
      - customer_id: string or empty
      - meter_id: string or empty

    The model must return strict JSON only. This function will attempt to parse it.
    """
    prompt = textwrap.dedent(f"""
    Parse the following user question and return a JSON object (no extra text) with these keys: intent, output_type, date, needs_customer, needs_meter, needs_revenue, customer_id, meter_id.
    - intent: 'forecast' if the user asks for a revenue forecast, otherwise 'nl2sql'.
    - output_type: one of 'graph', 'table', 'nl'.
    - date: ISO date 'YYYY-MM-DD' if present, else empty string.
    - needs_customer/needs_meter/needs_revenue: booleans indicating whether the question references those data domains.
    - customer_id/meter_id: the exact id if present in the question, else empty string.

    Question: {question}
    """).strip()

    try:
        resp = chat(model=MODEL, messages=[
            {"role": "system", "content": "You MUST respond with a single JSON object only, no explanation."},
            {"role": "user", "content": prompt}
        ], stream=False)

        content = ""
        if isinstance(resp, dict):
            msg = resp.get("message") or {}
            if isinstance(msg, dict):
                content = msg.get("content", "")
            else:
                content = str(resp)
        else:
            try:
                content = resp.message.content
            except Exception:
                content = str(resp)

        content = content.strip()
        # Try to load JSON
        import json
        try:
            return json.loads(content)
        except Exception:
            # attempt to extract JSON substring
            import re
            m = re.search(r"\{.*\}", content, re.DOTALL)
            if m:
                try:
                    return json.loads(m.group(0))
                except Exception:
                    pass
        # Fallback: conservative defaults
        return {
            "intent": "nl2sql",
            "output_type": "nl",
            "date": "",
            "needs_customer": False,
            "needs_meter": False,
            "needs_revenue": False,
            "customer_id": "",
            "meter_id": ""
        }
    except Exception:
        return {
            "intent": "nl2sql",
            "output_type": "nl",
            "date": "",
            "needs_customer": False,
            "needs_meter": False,
            "needs_revenue": False,
            "customer_id": "",
            "meter_id": ""
        }
